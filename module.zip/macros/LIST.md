# ソード・ワールド 2.5 サポート用ツール(for FoundryVTT)
# マクロコード

**00_yt2import.js**
ゆとシートIIインポート

**01_hpmprecover.js**
HP/MP回復

**02_initiative.js**
先制判定目標値

**03_monsterknowledge.js**
魔物知識判定目標値

**04_looting.js**
戦利品判定

**05_auraselect.js**
キャラクター周囲の選択

**06_templateselect.js**
テンプレート範囲内の選択
